package com.wh.festec.fragment;

public abstract class PermissionCheckerFragment extends BaseFragment{
}
