package com.wh.festec;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;

import com.wh.festec.fragment.LatteFragment;

public class ExampleFragment extends LatteFragment {
    @Override
    public Object setLayout() {
        return R.layout.fragment_hello;
    }

    @Override
    public void onBindView(@NonNull Bundle savedInstanceState, View rootView) {

    }
}
