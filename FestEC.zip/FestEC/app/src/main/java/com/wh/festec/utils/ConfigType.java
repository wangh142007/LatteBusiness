package com.wh.festec.utils;

public enum ConfigType {

    API_HOST,
    APPLICATION_CONTEXT,
    CONFIG_READY,
    ICON
}
