package com.wh.festec.fragment;

public abstract class LatteFragment extends PermissionCheckerFragment {
}
