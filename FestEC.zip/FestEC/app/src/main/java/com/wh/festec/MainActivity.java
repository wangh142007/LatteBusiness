package com.wh.festec;

import com.wh.festec.activity.ProxyActivity;
import com.wh.festec.fragment.LatteFragment;

public class MainActivity extends ProxyActivity {

    @Override
    public LatteFragment setRootFragment() {
        return new ExampleFragment();
    }
}
